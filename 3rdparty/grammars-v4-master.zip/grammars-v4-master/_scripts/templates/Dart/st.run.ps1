Test.exe $args
