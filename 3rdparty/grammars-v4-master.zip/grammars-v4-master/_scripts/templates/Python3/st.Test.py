# Generated from trgen <version>

import os
import sys
from antlr4 import *
from antlr4.error.ErrorListener import ErrorListener
from readchar import readchar
from <lexer_name> import <lexer_name>;
from <parser_name> import <parser_name>;
from datetime import datetime

def getChar():
    xx = readchar()
    if (xx == 0):
        return '';
    return xx

class MyErrorListener(ErrorListener):

    def __init__(self, q, t, o):
        super().__init__()
        self.had_error = False
        self.quiet = q
        self.tee = t;
        self.output = o

    def syntaxError(self, recognizer, offendingSymbol, line, column, msg, e):
        self.had_error = True
        if ( self.tee ):
            self.output.write(f"line {line}:{column} {msg}\n");
        if (not self.quiet):
            print(f"line {line}:{column} {msg}", file=sys.stderr);

tee = False
output_dir = None
show_tokens = False
show_tree = False
show_trace = False
encoding = "<file_encoding>"
error_code = 0
string_instance = 0
prefix = ""
quiet = False
perf = False
per_file = False
noop = False
total_tokens = 0
total_parse_seconds = 0
first_file_tokens = 0
first_file_parse_seconds = 0

def main(argv):
    global tee
    global output_dir
    global show_tokens
    global show_tree
    global show_trace
    global encoding
    global prefix
    global quiet
    global perf
    global per_file
    global error_code
    global total_parse_seconds
    global first_file_tokens
    global first_file_parse_seconds

    inputs = []
    is_fns = []
    prefix = ""
    i = 1
    while i \< len(argv):
        arg = argv[i]
        if arg == "-tokens":
            show_tokens = True
        elif arg == "-tree":
            show_tree = True
        elif arg == "-prefix":
            i = i + 1
            prefix = argv[i] + " "
        elif arg == "-input":
            i = i + 1
            inputs.append(argv[i])
            is_fns.append(False)
        elif arg == "-encoding":
            i = i + 1
            encoding = argv[i]
        elif arg == "-tee":
            tee = True
        elif arg == "-o":
            i = i + 1
            output_dir = argv[i]
            tee = True
        elif arg == "-x":
            while f := sys.stdin.readline():
                f = f.strip()
                inputs.append(f)
                is_fns.append(True)
        elif arg == "-q":
            quiet = True
        elif arg == "--perf":
            perf = True
        elif arg == "--per-file":
            per_file = True
        elif arg == "-trace":
            show_trace = True
        elif arg[0] == "-":
            # Ignore
            noop = True
        else:
            inputs.append(argv[i])
            is_fns.append(True)
        i = i + 1
    if len(inputs) == 0:
        ParseStdin()
    else:
        start_time = datetime.now()
        for f in range(0, len(inputs)):
            if is_fns[f]:
                ParseFilename(inputs[f], f)
            else:
                ParseString(inputs[f], f)
        end_time = datetime.now()
        diff = end_time - start_time
        diff_time = diff.total_seconds()
        if (not quiet):
            if not perf:
                print(f'{prefix}TT: {diff_time}', file=sys.stderr)
            else:
                warm_tokens = total_tokens - first_file_tokens
                warm_seconds = total_parse_seconds - first_file_parse_seconds
                warm_tps = str(int(warm_tokens / warm_seconds)) if (len(inputs) > 1 and warm_seconds > 0) else "n.a."
                first_tps = first_file_tokens / first_file_parse_seconds if first_file_parse_seconds > 0 else 0
                speedup = f'{(warm_tokens / warm_seconds) / first_tps:.2f}' if (len(inputs) > 1 and warm_seconds > 0 and first_tps > 0) else "n.a."
                print(f'{prefix}PT: {total_parse_seconds}', file=sys.stderr)
                print(f'{prefix}OT: {diff_time - total_parse_seconds}', file=sys.stderr)
                print(f'{prefix}TT: {diff_time}', file=sys.stderr)
                print(f'{prefix}PR: {int(total_tokens / total_parse_seconds) if total_parse_seconds > 0 else 0}', file=sys.stderr)
                print(f'{prefix}Post-warmup PR: {warm_tps}', file=sys.stderr)
                print(f'{prefix}Post-warmup speed up: {speedup}', file=sys.stderr)
    sys.exit(error_code)

def ParseStdin():
    sb = ""
    ch = getChar()
    while (ch != ''):
        sb = sb + ch
        ch = getChar()
    input = sb
    str = InputStream(input);
    DoParse(str, 'stdin', 0)

def ParseString(input, row_number):
    global string_instance
    str = InputStream(input)
    DoParse(str, 'string', row_number)
    string_instance = string_instance + 1

def ParseFilename(input, row_number):
    global encoding
    if (encoding == ""):
        encoding = "utf-8"
    str = FileStream(input, encoding)
    str.name = input
    DoParse(str, input, row_number)

def DoParse(str, input_name, row_number):
    global tee
    global output_dir
    global show_tokens
    global show_tree
    global show_trace
    global encoding
    global prefix
    global quiet
    global per_file
    global error_code
    global total_tokens
    global total_parse_seconds
    global first_file_tokens
    global first_file_parse_seconds

    if output_dir is not None:
        abs_name = os.path.abspath(input_name)
        root = os.path.abspath('../<example_dir_unix>')
        rootless = os.path.relpath(abs_name, root)
        if rootless == '..' or rootless.startswith('..' + os.sep) or os.path.isabs(rootless):
            rootless = os.path.basename(abs_name)
        out_name = os.path.join(output_dir, rootless)
        os.makedirs(os.path.dirname(out_name) or '.', exist_ok=True)
    else:
        out_name = input_name
    lexer = <lexer_name>(str)
    lexer.removeErrorListeners()
    if (tee):
        output = open(out_name + ".errors", "w")
    else:
        output = sys.stderr
    listener_lexer = MyErrorListener(quiet, tee, output)
    lexer.addErrorListener(listener_lexer)
    # lexer.strictMode = false
    tokens = CommonTokenStream(lexer)
    parser = <parser_name>(tokens)
    parser.removeErrorListeners()
    listener_parser = MyErrorListener(quiet, tee, output)
    parser.addErrorListener(listener_parser)
    if (show_tokens):
        i = 0
        while True:
            ro_token = lexer.nextToken()
            token = ro_token
            token.tokenIndex = i
            i = i + 1
            print(token, file=sys.stderr)
            if (token.type == -1):
                break
        lexer.reset()
    if (show_trace) :
        parser.setTrace(False)
        ParserATNSimulator.trace_atn_sim = True
        PredictionContext._trace_atn_sim = True
    start_time = datetime.now()
    tree = parser.<start_symbol>()
    end_time = datetime.now()
    token_count = len(tokens.tokens)
    total_tokens += token_count
    diff = end_time - start_time
    diff_time = diff.total_seconds()
    total_parse_seconds += diff_time
    if row_number == 0:
        first_file_tokens = token_count
        first_file_parse_seconds = diff_time
    result = ''
    if listener_parser.had_error or listener_lexer.had_error:
        result = 'fail'
        error_code = 1
    else:
        result = 'success'
    if (show_tree):
        if (tee):
            f = open(out_name + '.tree', 'w', encoding='utf-8')
            f.write(tree.toStringTree(recog=parser))
            f.close()
        else:
            print(tree.toStringTree(recog=parser), file=sys.stderr)
    if (not quiet and per_file):
        sys.stderr.write(prefix)
        sys.stderr.write('Python3 ')
        sys.stderr.write(f'{row_number}')
        sys.stderr.write(' ')
        sys.stderr.write(input_name)
        sys.stderr.write(' ')
        sys.stderr.write(result)
        sys.stderr.write(' ')
        sys.stderr.write(f'{diff_time}')
        sys.stderr.write(' s ')
        sys.stderr.write(f'{token_count}')
        sys.stderr.write(' tokens ')
        sys.stderr.write(f'{int(token_count / diff_time) if diff_time > 0 else 0}')
        sys.stderr.write(' pr\n')
    if (tee):
        output.close()

if __name__ == '__main__':
    main(sys.argv)
