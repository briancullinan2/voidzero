-- A27003A.ADA

--                             Grant of Unlimited Rights
--
--     Under contracts F33600-87-D-0337, F33600-84-D-0280, MDA903-79-C-0687,
--     F08630-91-C-0015, and DCA100-97-D-0025, the U.S. Government obtained 
--     unlimited rights in the software and documentation contained herein.
--     Unlimited rights are defined in DFAR 252.227-7013(a)(19).  By making 
--     this public release, the Government intends to confer upon all 
--     recipients unlimited rights  equal to those held by the Government.  
--     These rights include rights to use, duplicate, release or disclose the 
--     released technical data and computer software in whole or in part, in 
--     any manner and for any purpose whatsoever, and to have or permit others 
--     to do so.
--
--                                    DISCLAIMER
--
--     ALL MATERIALS OR INFORMATION HEREIN RELEASED, MADE AVAILABLE OR
--     DISCLOSED ARE AS IS.  THE GOVERNMENT MAKES NO EXPRESS OR IMPLIED 
--     WARRANTY AS TO ANY MATTER WHATSOEVER, INCLUDING THE CONDITIONS OF THE
--     SOFTWARE, DOCUMENTATION OR OTHER INFORMATION RELEASED, MADE AVAILABLE 
--     OR DISCLOSED, OR THE OWNERSHIP, MERCHANTABILITY, OR FITNESS FOR A
--     PARTICULAR PURPOSE OF SAID MATERIAL.
--*
-- CHECK THAT IN A STRING LITERAL, CONSECUTIVE HYPHENS
-- ARE PERMITTED WITHOUT INDICATING A COMMENT,
-- AND THAT IN A COMMENT, A SINGLE DOUBLE-QUOTE IS
-- PERMITTED WITHOUT INDICATING A STRING LITERAL.

-- PWB  03/04/86

WITH REPORT; USE REPORT;
PROCEDURE A27003A IS

     -- COMMENT :  "  IS PERMITTED HERE.

     STR1 : CONSTANT STRING := "AB--C";
     STR2 : STRING (1..10);

BEGIN

     TEST ("A27003A", "CONSECUTIVE HYPHENS PERMITTED IN " &
                      "STRING LITERAL, AND QUOTE PERMITTED " &
                      "IN COMMENT");

     STR2 := STR1 & "--ABC";
     -- COMMENT : " IS PERMITTED HERE.

     RESULT;

END A27003A;
