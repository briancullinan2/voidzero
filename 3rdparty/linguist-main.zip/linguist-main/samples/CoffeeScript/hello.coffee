console.log "Hello, World!"
